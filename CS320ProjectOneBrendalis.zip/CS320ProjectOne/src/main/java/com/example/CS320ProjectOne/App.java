package com.example.CS320ProjectOne;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome to Project One by Brenda Sanchez" );
    }
}
