package com.example.CS320ProjectOne;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {
    @Test
    void testTaskCreation() {
        Task task = new Task("T123456789", "Update UI", "Revamp the user interface.");
        assertNotNull(task);
        assertEquals("Update UI", task.getName());
    }

    @Test
    void testTaskConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Update UI", "Revamp the user interface."));
        assertThrows(IllegalArgumentException.class, () -> new Task("T123456789", null, "Revamp the user interface."));
        assertThrows(IllegalArgumentException.class, () -> new Task("T123456789", "Update UI", null));
    }

    @Test
    void testTaskFieldLength() {
        assertThrows(IllegalArgumentException.class, () -> new Task("T1234567890A", "Update UI", "Revamp the user interface."));
        assertThrows(IllegalArgumentException.class, () -> new Task("T123456789", "Update the user interface completely", "Revamp the user interface."));
        assertThrows(IllegalArgumentException.class, () -> new Task("T123456789", "Update UI", "Revamp the user interface with multiple new features and optimizations."));
    }
}

