package com.example.CS320ProjectOne;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {
    @Test
    void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        Appointment appointment = new Appointment("AP1234567", futureDate, "Checkup Meeting");
        assertNotNull(appointment);
        assertEquals("Checkup Meeting", appointment.getDescription());
    }

    @Test
    void testAppointmentConstraints() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("AP1234567", pastDate, "Past Meeting"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, new Date(), "Null ID Meeting"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("AP1234567", new Date(), null));
    }

    @Test
    void testAppointmentIdAndDescriptionLength() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("AP12345678901", futureDate, "Checkup Meeting"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("AP1234567", futureDate, "This description is definitely way too long to be acceptable under any normal circumstances."));
    }
}
