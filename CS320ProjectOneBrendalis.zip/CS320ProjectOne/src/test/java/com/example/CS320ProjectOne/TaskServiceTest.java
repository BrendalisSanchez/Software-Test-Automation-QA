package com.example.CS320ProjectOne;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void testAddAndGetTask() {
        Task task = new Task("T123456789", "Update UI", "Revamp the user interface.");
        service.addTask(task);
        Task retrieved = service.getTask("T123456789");
        assertEquals("Update UI", retrieved.getName());
    }

    @Test
    void testUpdateTask() {
        Task task = new Task("T123456789", "Update UI", "Revamp the user interface.");
        service.addTask(task);
        service.updateTask("T123456789", "Refine UI", "Refine the user interface details.");
        Task updated = service.getTask("T123456789");
        assertEquals("Refine UI", updated.getName());
        assertEquals("Refine the user interface details.", updated.getDescription());
    }

    @Test
    void testDeleteTask() {
        Task task = new Task("T123456789", "Update UI", "Revamp the user interface.");
        service.addTask(task);
        service.deleteTask("T123456789");
        assertNull(service.getTask("T123456789"));
    }

    @Test
    void testUniqueTaskID() {
        Task task1 = new Task("T123456789", "Update UI", "Revamp the user interface.");
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task1));
    }
}
