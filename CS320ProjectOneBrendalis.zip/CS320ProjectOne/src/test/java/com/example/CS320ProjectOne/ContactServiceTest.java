package com.example.CS320ProjectOne;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddAndGetContact() {
        Contact contact = new Contact("ID12345678", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        Contact retrieved = service.getContact("ID12345678");
        assertEquals("Alice", retrieved.getFirstName());
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("ID12345678", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        service.updateContact("ID12345678", "Alicia", null, null, null);
        Contact updated = service.getContact("ID12345678");
        assertEquals("Alicia", updated.getFirstName());
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("ID12345678", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        service.deleteContact("ID12345678");
        assertNull(service.getContact("ID12345678"));
    }

    @Test
    void testUniqueContactID() {
        Contact contact1 = new Contact("ID12345678", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact1));
    }
}
