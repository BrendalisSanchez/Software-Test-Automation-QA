package com.example.CS320ProjectOne;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void testAddAndDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        Appointment appointment = new Appointment("AP1234567", futureDate, "Annual Review");
        service.addAppointment(appointment);
        assertNotNull(service.getAppointments().get("AP1234567"));

        service.deleteAppointment("AP1234567");
        assertNull(service.getAppointments().get("AP1234567"));
    }

    @Test
    void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment1 = new Appointment("AP1234567", futureDate, "Initial Consultation");
        service.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment1));
    }

    @Test
    void testAppointmentValidity() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(new Appointment("AP1234567", pastDate, "Invalid Meeting")));
    }
}
